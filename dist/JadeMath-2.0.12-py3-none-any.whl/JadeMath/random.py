pi = 3.141592653589
e = 2.718281




def c_to_f(celcius: float):
    f = celcius * (9/5) + 32
    return f


def f_to_c(fehrenheit: float):
    c = (fehrenheit - 32) * 5/9
    return c
