def velocity(velocity1, velocity2):
    vel = velocity2 - velocity1
    return vel


def acceleration(velocity: int, time: int):
    ac = velocity / time
    return ac


def add(num1, num2):
    sum = num1 + num2
    return sum


def subtract(num1, num2):
    sub = num1 - num2
    return sub


def product(num1, num2):
    product = num1 * num2
    return product


def divide(num1, num2):
    div = num1 / num2
    return div
